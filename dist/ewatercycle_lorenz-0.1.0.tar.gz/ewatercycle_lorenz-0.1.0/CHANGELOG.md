## Changelog

### v0.0.1
- add model
### v0.0.2 - 0.0.7
- changes to bmi which only show up once in container..
had minimal running product after 0.0.7

### v0.0.8 
- changes to bmi to fix grid and times
- now handles time in bmi which makes more sense
### v0.0.9
- typo in get_start_time method
## V0.1.0
- release!
